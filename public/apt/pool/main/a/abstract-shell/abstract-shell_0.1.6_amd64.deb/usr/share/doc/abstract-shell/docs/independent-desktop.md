# Abstract desktop essentials

Abstract uses standard Linux services rather than replacing NetworkManager,
BlueZ, UDisks, PipeWire, polkit, or the system's software manager.

## Where to find things

- Search Super for Default applications, Startup applications, Removable devices,
  Install applications, Software updates, Users and passwords, or Date and time.
- Settings → System tools groups defaults, startup, devices and installed tools.
  Tools that are not installed show a reason instead of a nonworking button.
- Desktop files support selection, copy, cut, paste, trash, Open With, Properties,
  cancellable transfers and dragging files into applications.
- Settings → Accessibility offers the screen reader, configured input-method
  setup and an installed on-screen keyboard. The keyboard requires the updated
  native compositor. It is not offered as a touchscreen lock-screen keyboard.
  Applications explicitly using `QT_IM_MODULE=fcitx` or `GTK_IM_MODULE=fcitx`
  also need the corresponding distribution Fcitx Qt/GTK frontend plugin; native
  text-input-v3 clients can use the Wayland engine directly.
- Supported battery charge limits can be saved through a narrowly scoped polkit
  helper. Stopping startup restoration leaves the current limit unchanged.

## Installation artifact

`python3 tools/build-desktop-package.py` builds a Debian/Ubuntu package without
installing it or changing the current session. It includes the native compositor,
shell, lock renderer, patched screen-sharing backend and system integration files.
The runtime binaries are built for this machine's distribution and architecture;
this is not a universal binary or a separate Linux distribution.

The installed login entry is Abstract. Program files use `/usr/lib/abstract`;
private state uses `$XDG_DATA_HOME/abstract` and settings use
`$XDG_CONFIG_HOME/abstract`. Existing checkout state is not silently migrated.
To copy supported state explicitly, as the desktop user without sudo:

```
python3 /usr/lib/abstract/tools/migrate-user-state.py --from /path/to/checkout/data
```

Migration preserves the source, keeps existing destination files, and uses the
SQLite backup API for an open database. Files outside that directory, such as a
legacy desktop-layout file, require an explicit separate copy. Do not run two
sessions against the same mutable data directory.

## Resource behavior and boundaries

Clipboard retention is one bounded in-memory item; it is not clipboard history.
Transfers use the existing file worker. Removable-device arrival uses bus events;
mount discovery is page-scoped. Optional input engines start only when already
configured. Portal recovery is bounded and does not terminate the desktop.

Shell code can reload while apps remain open. Changes to Wayland globals, native
rendering, input-method trust and portal ownership require a new login. Physical
suspend/resume, authentication, mixed-monitor behavior and browser capture must be
accepted on actual hardware separately from isolated protocol tests.

## Verification for this build

- 796 Python regressions passed, three skipped; 30 native Rust tests passed.
- Private Wayland/X11 clipboard owner-exit and primary-selection tests passed.
- Installed wvkbd typed into a real native Qt input; privileged keyboard globals
  were hidden from ordinary applications.
- Intel render-node DMA-BUF import passed without acquiring DRM master.
- Real desktop-to-application URI drag passed.
- Recheck: installed Fcitx composed and committed text through input-method-v2
  and text-input-v3 into a native GTK field on a private desktop.
- Recheck: all 16 taskbar edge/length/floating combinations passed actual native
  workarea, bounds and popup placement checks with no QML errors.
- Closed pins remain launchable on the taskbar. Prepared shell reloads retain
  verified observed background apps through a bounded, private one-shot handoff.
- Public ScreenCast portal delivered eight RGB frames through a PipeWire remote
  FD, including changing content; close and chooser-cancellation tests passed.
  This used a private bus and PipeWire server, not physical capture.
- Recheck: real Chrome WebRTC capture delivered eight changing frames through
  the portal, then stopped and removed its PipeWire source. Only a disposable
  browser profile and private desktop/services were used.
- Read-only host DDC/CI detection and brightness query passed (100/100); no
  brightness write was made. See `hardware-acceptance-2026-11-08.md`.
- Extracted package preflight passed against the host without acquiring its seat.
- Shell reload preserved three application windows and reported no QML errors.

Qt5 AT-SPI registration now passes with the isolated, distro-matched compatibility
library: startup-enabled and later-enabled accessibility both expose the real
tree, activate a button, focus a field, type through private Wayland input and
read text back. The 1.4 MB stripped library is used only by Abstract and its
Settings renderer. Host-library fingerprints disable the override after an
incompatible Qt update; ordinary applications keep their own system libraries.
All distribution patches, sources, licenses and the repeatable build inputs are
recorded. Qt5 Quick exposes Text/Action/Component for this field, not the optional
programmatic EditableText interface; keyboard editing and text reading passed.

Real authentication, suspend/resume, mixed-monitor behavior, connected-headset
battery reporting and physical charging-limit writes still require appropriate
hardware acceptance. See [the request recheck](request-recheck-2026-11-08.md) and
[read-only hardware checks](hardware-acceptance-2026-11-08.md).

See [operational readiness](operational-readiness.md) for the 0.1.2 startup,
watcher-lifetime, dependency and automatic first-login handoff fixes, plus the
subsequent successful real PAM authentication and HDMI brightness write checks.
