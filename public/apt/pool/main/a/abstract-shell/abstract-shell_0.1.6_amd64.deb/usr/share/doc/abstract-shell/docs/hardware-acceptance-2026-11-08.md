# Hardware acceptance — 2026-11-08

These are one-shot, read-only observations from the user's actual PC. They do not
constitute a brightness write, battery-limit change, pairing attempt, discovery
scan, logout, lock, suspend, monitor reconfiguration or application close.

| Area | Actual observation | What this establishes | Remaining acceptance |
| --- | --- | --- | --- |
| HDMI DDC/CI | Existing brightness backend detected one GF340A on `card1-HDMI-A-1`; VCP `0x10` returned current 100, maximum 100 | The desktop user can detect this monitor and read valid brightness through DDC/CI with current permissions. The slider has a real 0–100 source value. | A deliberate brightness write and visual response have not been exercised during this recheck. Hotplug/replacement and other monitors remain separate. |
| Audio output | Existing audio backend lists a named HDMI stereo sink as available | The output-name detection path works against the current audio server. | Physical media keys and real application playback/routing changes were not exercised. |
| Wired microphone | No source is active. HDA Intel PCH's current card profile is Off; analog input/duplex profiles report Not connected | There is a real hardware/profile explanation for the missing microphone. The panel exposes explicit device-profile recovery and now provides a connection/profile hint rather than an empty reason. | Plugging the headset into the correct socket, selecting the appropriate profile and recording sound require a deliberate physical check. No profile or recording stream was changed. |
| System battery | No system battery appears under the existing power backend | The desktop correctly reports no system battery instead of inventing a percentage or charge-limit support. | This PC cannot validate 60/80/etc firmware thresholds or charge-limit restoration. Those remain covered by synthetic tests until supported battery hardware is available. |
| Bluetooth battery | Existing BlueZ inventory: adapter available and powered, discovery inactive; one known device, none connected | Read-only BlueZ state works. No battery percentage is claimed without a connected device exposing Battery1. | A connected headphone that reports Battery1 is needed to verify its actual percentage. No discovery, pairing or Bluetooth state change was made. |

Raw bounded observation: `/tmp/abstract-hardware-readcheck.json`. Device serial
numbers and Bluetooth addresses were deliberately omitted from the report.

Other physical gates remain: real PAM password entry and recovery, VT switching,
suspend/resume, display hotplug/rollback across multiple monitors and mixed DPI,
and each application's updated native window-control behavior. Private compositor,
IME, clipboard and portal tests exercise their software paths without certifying
these physical operations.

## Follow-up operational validation

The HDMI write gate was subsequently exercised through the actual brightness
backend: **100 → 98 → 100**, with identity checks before writes and readback
afterward. No display-mode change or application close occurred.

The desktop user's real `swaylock` PAM service also authenticated successfully,
without locking the physical screen or changing any credentials/policy. Actual
physical lock input, VT recovery and resume remain distinct checks.
