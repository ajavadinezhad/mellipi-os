# Native protocol integration

The standalone DRM backend owns physical presentation. The nested preview does
not advertise a screen-lock manager: the parent desktop owns its screen lock.
A private QA fixture can explicitly enable a synthetic presentation boundary to
exercise ownership and failure handling. That fixture is never hardware security
certification.

## Lock invariants

- A lock is acknowledged only after every active output completes an opaque
  lock/black pageflip. A newly requested lock forces a fresh frame even if a prior
  lock's image was already black.
- Normal applications and shell layers are excluded from locked rendering.
  Ordinary keyboard and pointer grabs are cancelled; subsequent input goes only
  to a committed locker surface. An input-method grab cannot receive password
  keystrokes.
- Only the accepted owner can unlock. An unaccepted owner's unlock is a protocol
  error. If the owner crashes, the compositor remains locked and black.
- Captures are refused while locked. Normal window/workspace IPC commands are
  refused too; status remains available for recovery diagnostics.
- The hardware path still requires deliberate physical lock/unlock, VT and
  suspend/resume acceptance. A failed locker is recovered through the documented
  TTY/greeter path rather than silently revealing applications.

## Input, layers and idle

Top/overlay exclusive keyboard layers take priority over application focus.
On-demand layers receive keyboard focus on click. Closing or unmapping a focused
layer restores a surviving application in the current workspace. Client-owned
window controls remain owned by their applications; legacy X11 headers are
composed and transformed with the window instead of tracked by a separate timer.

`ext-idle-notify-v1` version 2 uses one-shot timers only for requested client
notifications. Input activity rearms them. Visible, mapped surfaces on the current
workspace can inhibit regular idle notifications; input-only notifications ignore
inhibitors. Switching workspaces, closing a surface or destroying the inhibitor
updates that state without polling.

Standard text-input-v3 is registered. The privileged input-method-v2 manager is
visible only to same-user peers whose executable is an installed, root-owned,
non-writable `/usr/bin/ibus-daemon` or `/usr/bin/fcitx5`. Trust is computed from
socket peer credentials before the client is inserted, avoiding backend lock
re-entry from a registry visibility filter. The development machine has Fcitx 5 installed. The session starts an engine
only when the user has configured it; installing the engine does not opt the
user in. The same installed engine is allowed the virtual-keyboard manager
needed to reinject unhandled keys; an ordinary client gets neither privileged
manager. The private Fcitx acceptance fixture exercises real Unicode preedit and
commit into a native GTK text-input-v3 field, beyond manager binding alone.

## Explicit capture

SHM screencopy exports ARGB8888 only, with at most eight pending requests and a
16-megapixel bound per frame. Readback occurs only for an explicit capture.
Buffers retain native output orientation as required by clients such as grim,
which apply the advertised output transform. Logical capture regions are clipped
and mapped to native coordinates for all rotations and reflections. The GLES
projection already accounts for Y; applying the texture-mapping flip again would
invert screenshots.

The DRM cursor uses a cached static Xcursor frame, choosing an installed
light/dark theme to match the desktop and falling back to a small built-in arrow.
Client-provided cursor artwork and per-request cursor exclusion remain separate
capabilities; the theme-matched desktop pointer does not establish those.

## Repeatable private checks

`tools/qa-native-security.py` creates its own temporary runtime and headless Sway
parent, then runs native clients against that independent socket. It exercises
idle delivery/inhibition, layer keyboard focus, text-input binding and privileged
manager visibility, actual grim capture for every output transform, and private
synthetic-presentation lock ownership/failure handling. It never routes input,
locking or capture commands to the physical session.

`cargo test --features drm --manifest-path compositor/Cargo.toml` includes crop
coordinates for all eight transforms and denies IME privilege to an ordinary
Unix-socket client. See the current task's logs for actual run results; the
presence of the harness does not itself establish a passing test or hardware
readiness.

Validation on 7 November 2026: all 12 grouped checks in the complete private
harness passed, including actual pointer-driven on-demand layer focus and all
eight grim screenshot orientations (`/tmp/orbit-security-final-qa.log`). The
12-test Rust suite also passed (`/tmp/orbit-native-all-rust-tests.log`). The
protocol run explicitly reports `hardware_validated: false`; physical DRM
lock/authentication are not covered by these passes.

Validation on 8 November 2026: `tools/qa-ime-native.py` passed with the installed
Fcitx engine. It created an input-method-v2 keyboard grab, sent a `U+263a` preedit
and committed `☺` through text-input-v3 into a real GTK entry. An owned private
D-Bus, headless parent and native compositor kept physical input, engine settings
and applications untouched. This verifies the standard Fcitx composition path,
not every optional multilingual engine or toolkit-specific frontend.

## Display confirmation recovery

The native display watchdog requests `output_checkpoint` before changing a mode.
The compositor captures the current configuration and returns an unpredictable
transaction token. `output_commit` consumes confirmation; `output_rollback`
restores only that recorded configuration. Rollback is permitted while locked
without allowing caller-provided mode changes through the lock guard. A one-shot
event-loop expiry also restores the checkpoint if the watchdog exits. A late
watchdog rollback for the most recently restored token is idempotent. No timer
runs when no display confirmation is pending.

These commands require the updated native compositor. They are not hot-installed
into an already running compositor; start a new Abstract login after upgrading.
