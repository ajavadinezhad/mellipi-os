# Abstract operational readiness

Abstract is an installed native desktop, not a replacement Linux distribution.
It uses standard Linux hardware/services and starts from the Abstract login entry.
The development checkout is not needed by the installed program.

## Operational fixes in 0.1.2

- Authentication-agent duplicate suppression is scoped to the current login.
  An agent left in another desktop cannot suppress this session's prompts.
- The session owner reaps exited startup launchers using SIGCHLD wakeups and its
  existing main loop. The running old owner had 13 exited GIO launchers retained;
  the updated owner adds no polling timer or worker thread.
- The package requires its core Wayland platform plugin, authorization agent,
  audio protocol/tools, file manager, terminal and standard icons. A minimal
  installation no longer depends on tools incidentally installed by Mint.
- Settings and the shell select the same available icon theme, including Adwaita
  when Mint icons are absent. Package purge cleans service-registration state;
  it does not delete user data or change the current hardware limit.
- The installed readiness command names the actual Abstract login entry. The
  terminal shortcut uses the system terminal alternative through GIO instead of
  assuming Xfce, with normal app environment and standard child reaping.
- Closed power, brightness and app-catalog models dispose their native watch
  engines immediately on the GUI thread. This fixes a worker-GC/Qt I/O race found
  during stress testing, without changing global GC policy or adding polling.
- The installed profile had never been used. Its previous snapshot was backed up
  before refreshing current settings, usage and a consistent SQLite backup from
  the active desktop. A one-time marker performs the final handoff only after
  the installed compositor is ready. It carries later edits and newly created
  notes, preserves changed destination files by fingerprint, and keeps backups.
  Checks/previews never consume the handoff. The marker is removed afterward.

## Actual validation

- The real `swaylock` PAM service authenticated the desktop user successfully.
  This test did not lock the screen, change credentials or open a PAM session.
- The real HDMI DDC backend changed brightness from 100 to 98 and restored 100,
  confirming the same write/read path used by the slider. Monitor identity was
  checked before each write. Resolution and app windows were untouched.
- Settings passed actual native pointer dragging, titlebar minimize/maximize,
  restore, close/reopen and every settings page in a private desktop.
- The production native binary passed 12 grouped private checks covering keyboard
  layers, idle inhibition, captures in all eight transforms, lock ownership,
  rejected unlock/capture requests, locker-death fail-closed behavior and locked
  IPC restrictions. Synthetic lock presentation is not physical KMS certification.
- Session cleanup and authentication scoping have dedicated fixture/owned-process
  regressions. No unrelated process is reaped, stopped or inspected for content.

## Activation and hardware boundaries

The current compositor and applications remain running. A compositor and its
session owner cannot be replaced in place while retaining their Wayland clients.
The updated owner, native input-method grants and portal ownership activate on
one normal logout/login into Abstract; shell-only updates do not require that.
Mint/Xfce remains a recovery option.

This desktop PC has no system battery and no connected Bluetooth headset. Their
physical percentages/charging thresholds cannot be verified here. Real secure
lock/unlock input on the physical output, VT recovery, suspend/resume and mixed
monitor hotplug still require deliberate physical acceptance; passing PAM and
private protocol tests do not pretend to certify those operations.

## Release verification

The final 0.1.2 regression run passed **833 tests, three skipped**
(`/tmp/abstract-operational-final-suite.log`). Production Qt5 targeted checks
also passed. The real GIO terminal activation path was exercised with an owned
helper containing spaces and a literal desktop field-code token in its filename;
its environment did not inherit shell-only flags or the test private variable.
The automatic handoff was tested for later source edits, newly created notes,
live SQLite backup, destination-edit preservation, private marker permissions,
and exclusion from checks/previews. It executes only after an installed real
compositor reports readiness, before its shell opens the profile.

Package upgrade simulation on this PC requests only Abstract's update: zero new
packages, zero removals. The updated session's event-driven reaper and login-agent
scoping activate with its new session owner; they cannot change the old owner's
already-imported code in place.

Terminal, desktop-shortcut and Open With activation are isolated from the shell
process group. Real owned launch fixtures verify both file-argument preservation
and independent process groups, so shell recovery cannot terminate those apps.

## Installed release acceptance

Abstract 0.1.2 was rebuilt and installed with the final detached-launch fixes.
The installed launcher and all 14 Settings sections passed in a private nested
session with no QML errors. The remembered login wrapper reports readiness for
Abstract and delegates to the installed release. The private state handoff remains
armed with mode 0600; readiness checks and nested QA did not consume it.

The physical shell remained healthy with no QML errors. Its reload guard found
the desktop locked and correctly refused to replace any process. No unlock,
logout, compositor replacement or user-app termination was performed. The new
session owner and updated shell activate at the next normal login.

## Daily workflow improvements in 0.1.3

Quick Controls now has a direct volume slider and mute button. Output and
microphone sliders use one-percent keyboard steps. Enter in the Wi-Fi password
field follows the same connection path as its button and clears the password.
Connection settings has a direct link; the guide documents fallback volume keys.
The logout review uses a content-sized empty state while retaining application
save/close waiting, system protections, cancellation and explicit confirmation.

Thirty-eight focused package, keyboard, audio and session tests passed. Installed
launcher plus all fourteen Settings sections passed in a private nested desktop
with no QML errors. The shell-only update succeeded on the physical session,
preserving five application windows and the compositor; no QML errors occurred.
No physical audio, lock, logout or power action was used for these checks.

## Completion release 0.1.4

- Lock presentation shows the current keyboard layout during entry/checking/error,
  fits short logical outputs, and displays read-only network carrier status. No
  notifications, SSIDs or system controls are exposed. Battery remains conditional.
- Saved monitor configuration is restored only for newly connected outputs, with
  existing user preview/rollback transactions respected. Application is event-driven.
- Audio commands have an independent bounded worker so Wi-Fi authentication cannot
  stall volume or microphone changes. Connection/scan progress and errors are
  visible, conflicting requests guarded, and explicit Refresh requests discovery.
- Logout lists shrink/scroll to keep confirmation and cancellation accessible.
- Device dispatch failures are visible; GIO owns detached system-tool activation.
- Startup apps can be added explicitly from installed applications, scoped to
  Abstract and effective only at the next login. Existing entries can be disabled.
- Keyboard choices use bounded installed XKB layout metadata, with fixed fallback.
- Empty launcher searches have a Show all apps recovery. Default MIME labels name
  their actual associations. An Updates icon beside Quick Settings's settings link
  opens the installed package manager, with no polling/updater service. Abstract
  packages need a configured distribution repository for remote update discovery;
  this icon does not invent a package source or silently install software.

Compositor changes require a normal future login; no running Wayland compositor
or user applications are replaced by package installation or shell-only refresh.

### 0.1.4 installed acceptance

The full regression run completed 858 tests with three skips and no failures
(`/tmp/abstract-completion-release-tests-final.log`). Final launcher layout and
update-entry cleanup passed twelve further production Qt5 tests without warnings.
The native Rust suite passed35/35 and the private native security harness passed
all grouped capture/focus/lock checks. The installed launcher and all14 Settings
sections passed with no QML errors in private state. Source and installed final
QML, Settings bridge, compositor and locker were compared directly.

The package is installed. The physical session was locked when the guarded shell
refresh ran; it refused before signaling any process. The current compositor and
apps remain running. A normal future login activates the complete installed
release; no physical lock/unlock, logout, display hotplug or power action was
performed to manufacture acceptance. Earlier0.1.3 shell refresh preserved five
app windows, but the final0.1.4 refresh was deliberately deferred.

## Installation release 0.1.6

The supported artifact baseline is Ubuntu 24.04 amd64/systemd-logind. Core and
complete-profile packages have explicit Qt shell-integration/SVG dependencies,
automatic ELF dependency generation and architecture checks. The complete profile
adds distro login/services/apps and a small themed greeter without rewriting PAM.
See clean-install-acceptance.md for the exact fresh-VM evidence and recovery.

A final input-startup fix drains already-queued libinput events through the normal
EventSource callback once before sleeping, rearmed after VT resume. It adds no
periodic wakeup and discards no events. Input metadata now uses actual keymap
layout names. Thirty-eight native tests passed, including the one-shot lifecycle,
quiet idle, resume re-registration and four-layout names.

The previous release's cold-install certificate and lifecycle evidence remain
separate from the final artifact's upgrade/first-input verification. Certificates
record exact package hashes rather than treating modified candidates as identical.
