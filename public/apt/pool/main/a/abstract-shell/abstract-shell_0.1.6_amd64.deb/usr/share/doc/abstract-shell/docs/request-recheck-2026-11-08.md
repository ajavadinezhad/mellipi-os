# Abstract request recheck — 2026-11-08

This recheck compares the conversation's requests with the current implementation,
including later instructions that replaced earlier ones. “Implemented” means a
reachable source path and regression coverage exist; it does not imply every
physical application, device or login combination has been exercised. Agents
kept the user's apps and compositor running. Current-session changes and
next-login native changes must be reported separately.

## Shell, appearance and everyday interaction

| Requested behavior | Current evidence | Status / practical boundary |
| --- | --- | --- |
| A desktop shell with native Wayland behavior, polished and lightweight on 2 cores / 4 GB | `session/native_session.py`, `compositor/src/drm.rs`, `native/Desktop.qml`; economy defaults in `preferences.py`; bounded logs and event-driven controllers | Implemented. Performance on every workload is not established by source or unit tests. |
| Replace screenshot workspace effects with actual native slides; forward up, backward down | `compositor/src/workspaces.rs`, native render paths, `tests/test_native_backend.py`, `tests/test_session_retirement.py` | Implemented live-surface transitions. The retired capture transition is not a feature to restore. Updated native binary needs a new login. |
| Accent-colored workspace position line moving with slide | `native/OrbitSpine.qml` workspace indicator; duration/easing matches native economy/balanced motion; `tests/test_spine_design.py` | Implemented. Real QML test verifies visibility, movement and accent. The indicator begins from received workspace state; it is not a continuously polled native frame counter. |
| Workspace shortcuts including Ctrl+Alt+arrows | `shortcut_settings.py`, native input dispatch; `tests/test_shortcut_settings.py`, `tests/test_hardware_keys.py` | Implemented. Physical key/firmware combinations require device acceptance. |
| Smooth open/minimize/maximize and panel transitions without expensive effects | `compositor/src/window_motion.rs`, native rendering, `native/QuickPanel.qml`, `native/UnifiedLauncher.qml`; motion tests | Implemented with reduced-motion/economy controls. App-specific configure timing still needs live application acceptance. |
| One searchable Apps + Windows view, Super key, centered launcher | `native/UnifiedLauncher.qml`, `panel_policy.py`, native shortcuts; `tests/test_action_search_ui.py`, `tests/test_panel_geometry.py` | Implemented; searches apps, windows and system actions. Saved layouts and Files & notes remain explicit secondary destinations. |
| Find common actions such as logout/login easily | System action aliases/deep links in `action_targets.py`, `native_app.py:systemActions`, UnifiedLauncher; Getting around page | Implemented. Session actions execute only through the app-aware review path where appropriate. |
| App sorting by frequent/recent/name; pin from Super | Launcher segments and pin button, `app_usage.py`; `tests/test_app_usage.py`, `tests/test_fold_ui.py` | Implemented. Usage counts are local and clearable. |
| Pins should remain on the taskbar even when apps close | `native/OrbitSpine.qml`, `native_app.py:taskbarBodyRect`; new `tests/test_spine_design.py` pinned lifecycle regression | **Fixed in this recheck.** Closed pins were previously filtered out. They now remain launchable; inactive running apps have a small marker, closed pins do not. Fit geometry includes pins and internal Settings. |
| Settings is a normal draggable/minimizable/maximizable window, centered initially, recoverable from taskbar | `native/SettingsWindow.qml`, `settings_host.py`; `tests/test_settings_window.py`, `tests/test_settings_task.py` | Implemented. No detached overlay frame is used for app controls. |
| Alt+Tab and selecting an app must raise it above maximized apps | `native/WindowSwitcher.qml`, native window actions/Xwayland handling; `tests/test_window_actions.py`, `tests/test_xwayland_controls.py` | Implemented adapters and regressions. Chrome, Telegram and terminal behavior still require checking in the updated physical session. |
| Correct app minimize/maximize/close controls, no trailing detached buttons | Native compositor decoration policy and handlers; `tests/test_decoration_policy.py`, `tests/test_frame_controls.py`, `tests/test_window_control_readiness.py` | Detached-control surface removed. Native/client decorations are negotiated; app-specific physical acceptance remains. |
| Compact and extra compact density; aligned icons and contained borders | `native/Theme.qml`, `native/OrbitSpine.qml`, `panel_policy.py`; `tests/test_density.py`, `tests/test_spine_design.py` | Implemented. Four-edge bounds are privately tested; all themes, text scales and monitor combinations are not a visual acceptance claim. |
| Taskbar top/bottom/left/right, full edge/fit, floating | Appearance controls, `panel_policy.py`, OrbitSpine; `tests/test_taskbar_preferences.py`, `tests/test_taskbar_policy.py` | Implemented. Classic mode migrates to the sole shipped Fold/Spine layout. |
| Arrows point toward panel content on all four edges | OrbitSpine background icon derives from edge | Implemented; no upside-down shared arrow remains. |
| Popovers beside their icons, context menus and tooltips anchored rather than random | `panel_policy.py`, `native_app.py:itemScreenPoint`, `queueItemTooltip`, `syncContextSurface`; `tests/test_panel_geometry.py`, `tests/test_tooltips.py` | Implemented with shared body geometry and live item tracking. Mixed-DPI/multi-monitor physical placement remains an acceptance gate. |
| Outside-click dismiss and quick-tab changes should not steal apps or close unexpectedly | Overlay input masks/focus handling; `tests/test_panel_policy.py`, `tests/test_panel_geometry.py`, `tests/test_control_lifetime.py` | Implemented source/regressions. Live application focus and popup chains still need acceptance across clients. |
| Quick settings tabs; separate sound/music; compact icon actions; no unnecessary scrolling | `native/QuickPanel.qml`, `native/SessionPanel.qml`, `native/MusicPanel.qml`; `tests/test_network_power_ui.py`, `tests/test_audio_ui.py` | Implemented. Sound's quick entry links to devices/microphone settings; screenshot is not a quick-settings action. |
| Screenshot icon, display/area/window choice, clipboard default, destination opens folder; no Last screenshot button | `native/ScreenshotPanel.qml`, `native/WindowCapturePicker.qml`, `screenshots.py`; `tests/test_screenshots.py`, `tests/test_native_control_gates.py` | Implemented; screenshot remains at taskbar icon, not Settings. Native PNG clipboard protocol is separately covered. |
| Background/tray apps grouped, sharp icons, closed ChatGPT still discoverable | `background_apps.py`, `tray.py`, `native/TrayPanel.qml`; `tests/test_background_apps.py`, `tests/test_tray.py` | Implemented for observed processes. **Fixed in this recheck:** graceful reload now hands off bounded, revalidated records within the same native session; already-windowless apps stay discoverable after a prepared reload. No global process scan is introduced. |
| Notifications open their originating app | `desktop.notification_target`, `native_app.py:openNotification`; `tests/test_notification_actions.py` | Implemented desktop ID/app/window matching and declared actions. Apps with missing or false identity metadata remain application-dependent. |
| Resource usage and signed-in user | `resource_usage.py`, `native/UsagePanel.qml`, taskbar hint; `tests/test_resource_usage.py` | Implemented with page-scoped sampling and guarded unavailable values. |
| Dark/light/Black and additional cohesive themes, dropdown, matching wallpaper/borders/lock | Theme presets, ThemePicker, wallpaper SVGs, native palette path; `tests/test_theme_presets.py`, `tests/test_theme_wallpapers.py`, `tests/test_native_palette.py`, `tests/test_lock_background.py` | Implemented. Native border capability changes require next login. GTK/Qt app interiors depend on supported app theming; forced identical appearance for every app is not promised. |
| Accent changes, square/soft/round shell corners, themed pointer | Appearance controller, Theme.corner, pointer integration; appearance/cursor tests | Implemented shell corners and theme-aware pointers. Existing `shell_cursor.py` can accent the shell arrow; the native fallback selects light/dark variants. App-supplied resize/text cursors remain app-controlled. |
| Lock screen with a normal password textbox, theme wallpaper, clock/date/user/battery and little explanatory text | Patched lock runtime, `native/lock-textbox-render.h`, `native/lock-status.h`; lock textbox/status/clock tests | Implemented render and launch behavior. Actual PAM unlock, suspend/resume and emergency VT recovery are physical acceptance gates. No forced lock was run. |
| Desktop icons, drag, rubber-band selection and right-click file operations | `desktop_icons.py`, `native/DesktopIcons.qml`, `file_transfers.py`; desktop/file-transfer tests and private URI drag fixture | Implemented. Rubber-band uses the theme accent; outward URI drag was verified privately. |
| Undo arrangements and saved layouts | `arrangements.py`, `native/LayoutsPanel.qml`; arrangement engine/UI tests | Implemented bounded saved layouts and verified undo, including keeping failed-save drafts and rejecting hidden app activation in Layouts view. |
| Abstract product branding; Abstract OS only for repository | Current visible taskbar, Settings, launcher, lock text and package metadata | Implemented product-facing naming. Internal `orbit-*` protocol IDs, paths and historical audit titles remain compatibility identifiers, not visible branding to replace blindly. |

## System and integration requests

| Requested behavior | Current evidence | Status / practical boundary |
| --- | --- | --- |
| Select sound output, microphone input and profiles; mute icons; media keys | `system_services.py`, `native/AudioDevicePicker.qml`, `native/AudioProfilePicker.qml`, native input dispatch; audio device/profile/subscription/queue tests | Implemented. This recheck also fixed the empty-input recovery hint: connect a microphone and use Device profiles if the analog card is Off. Actual host read-only inspection found a named HDMI output but no microphone sources, consistent with the unplugged headset. Physical headset/media-key acceptance remains separate. |
| Bluetooth connect/disconnect and headphone battery percentage | `bluetooth.py`, Battery1 integration; Bluetooth/code tests | Implemented. Read-only inspection confirmed a powered BlueZ adapter, discovery off, one known device and none connected. Actual headphone battery reporting remains unverified without a connected reporter. |
| HDMI monitor brightness via DDC/CI; monitor identity and safe writes | `brightness.py`, DDC tool integration; brightness tests | Implemented. This recheck detected GF340A on card1-HDMI-A-1 and read valid VCP10 brightness 100/100 with current permissions. No brightness write was made, so write/restore behavior still needs physical acceptance. |
| System battery percentage, health and supported 60/80/etc charging limits | `power_controls.py`, `privileged_controls.py`, installed `abstract-charge-limit`, policy and boot service; power/privileged-charge tests | Implemented with device identity validation and explicit authorization. This desktop exposes no system battery; firmware threshold behavior cannot be physically certified here. No real battery setting was changed by this audit. |
| Input device settings, layouts, lock policy and display controls with rollback | `input_settings.py`, `display_controls.py`, native input/output controls and watchdog; input/display/rollback tests | Implemented. Physical hotplug, lock-time rollback and mixed monitors require acceptance distinct from fake-socket tests. |
| Desktop-neutral defaults, startup, drives, users, date/time and software controls | `desktop_tools.py`, `system_tools_data.py`, `device_monitor.py`, SystemToolsPanel; tool/data/UI tests | Implemented built-in defaults/startup/devices plus discovery of installed standard frontends. Missing frontends are visibly unavailable rather than dead buttons. |
| Clipboard retention, primary selection, screen-sharing and efficient app buffers | Native clipboard and DMA-BUF integrations; private clipboard/GBM/portal fixtures | Real private clipboard/primary/GPU import and portal frames passed in the preceding build. This recheck also passed actual Chrome getDisplayMedia: 8 WebRTC frames, 4 distinct canvas hashes, 860×640, then track stop removed the private PipeWire source. Live user-profile/browser behavior remains a separate acceptance boundary. |
| Independent installable session without losing settings | Package builder, installed launcher, migration utility, session preflight; package/migration tests | Implemented and installed. Supported checkout data was copied without overwrite; current apps/session were preserved. |
| Input methods and accessibility, including on-screen keyboard | `session/assistive.py`, `desktop_tools.py`, restricted native keyboard/input-method globals | OSK typing privately passed. This recheck fixed Fcitx’s missing narrowly trusted virtual-keyboard grant. Actual installed Fcitx Unicode preedit/commit into a native GTK text-input-v3 field now passed through input-method-v2 (`tools/qa-ime-native.py`). Real Qt5 AT-SPI startup and later activation now pass for Abstract with the isolated compatibility runtime; button actions, focus, private keyboard typing and text reads are verified. |

System agent ran **156 focused tests**, plus **29 focused audio tests** after the empty-input hint correction, in this recheck. This count is not a new
physical headset, DDC, power, browser or suspend/resume acceptance claim.

## Requests deliberately superseded

- AI was postponed by the user. Intelligence stays development-gated and is not
  a missing production surface.
- Sharing was explicitly removed. Historical storage/protocol compatibility is
  not a reason to restore sharing buttons or start an idle object store.
- Classic mode was later removed. Four taskbar directions and one current layout
  supersede earlier Classic/Spine feature-parity requests.
- Detour / Open briefly was explicitly removed and should not return.
- The old Orbit/Sway login and screenshot transitions were explicitly retired.
  Private Sway fixtures are test infrastructure, not a second shipped desktop.
- The early request for two top sections that can join/separate preceded the sole
  four-edge taskbar design. The old `topbarConnected` compatibility preference is
  not a current user-visible alternative shell mode.
- Early screenshot and power placements were later narrowed: screenshot stays
  beside its taskbar icon; Settings offers configuration, not repeated power
  action grids. Quick actions, search aliases and full configuration pages serve
  different task depths and are not automatically duplicate panels.

## Newly fixed and unresolved findings

1. **Closed pins missing from taskbar — fixed.** Real Qt5 QML tests now verify
   closed-pin visibility, keyboard launch, running-to-closed transitions and
   consistent fit geometry. Focused Spine + taskbar suite: **10 tests passed**.
2. **Already-windowless background apps after prepared shell reload — fixed.**
   `BackgroundApps.saveHandoff()` writes at most 64 observations into a private,
   32 KiB, one-use runtime checkpoint, valid for 60 seconds and bound to the exact
   native control socket instance. Restore revalidates ownership, desktop ID,
   executable, process birth and pidfd liveness. `prepare-reload` exports it;
   startup consumes it. Tests cover live continuity, process exit, stale records,
   replaced compositor sockets, public files and symlinks. No process enumeration,
   idle polling or long-lived app history is added. An unexpected crash before
   preparation and the first upgrade from an old shell cannot export old records;
   apps not observed in a window remain intentionally unknown.
3. **Retired background notifiers and worker garbage collection — hardened.**
   A retired notifier and its tracker are now explicitly rooted until Qt finishes
   deferred C++ deletion, then released on the next GUI event turn. This prevents
   worker-thread cyclic GC from finalizing their wrappers on a foreign thread,
   and avoids recursively destroying a parent inside its child's destructor.
   A forced worker-GC regression verifies this lifecycle. Qt5 background/control
   suite: 24 passed. Repeated Qt6 suite: 48 passed, plus an earlier 24-test pass.
4. **Qt5 screen-reader registration and later activation — fixed.** A private,
   distro-matched QtWayland compatibility library retains the distribution patch
   series and adds connection readiness and event-driven status handling. Real
   startup-enabled and later-enabled AT-SPI tests now verify the tree, button
   activation, focus, private-keyboard typing and text reading. The override is
   limited to Abstract/Settings and fingerprint-gated after Qt updates. Qt5 Quick
   does not offer the optional programmatic EditableText interface for this field;
   normal keyboard editing and text reading are verified.
5. **Physical acceptance remains distinct.** Real authentication/VT recovery,
   sleep/resume, missing or hotplugged displays, mixed DPI, HDMI DDC/CI, physical
   headset and media keys, live user-profile/browser behavior, and each GTK/Qt/X11 app's window
   chrome cannot be declared passed solely because the isolated tests pass.

## Verification in this recheck

This agent ran native Qt5 offscreen `tests.test_spine_design` and
`tests.test_taskbar_policy`: **10 passed**. Background-app, control-lifetime and
control-status tests: **24 passed**, using only owned temporary sockets and child
processes. The controls, screenshots and test
fixtures belong to an isolated QML scene; no user window was moved or closed.
The earlier complete-suite counts in other reports describe their executed
builds, not a fresh full run for this recheck. Root will record the final combined
checks and rollout after all agents finish.


The finite browser check is `tools/qa-browser-screencast-native.py`. It uses a
throwaway HOME/profile, private native compositor, private bus and PipeWire, and
an owned loopback test page/CDP connection. No host tabs, account state or devices
are addressed. The test explicitly requests a monitor and uses Chrome's test-only
first-screen selection switch; private PipeWire ports are linked without starting
a physical device manager. This verifies actual browser WebRTC frame delivery and
release, not the user's existing session portal activation or ordinary chooser UI.
The switch and deferred-list behavior were checked against Chromium's
[desktop media list controller](https://raw.githubusercontent.com/chromium/chromium/main/chrome/browser/ui/views/desktop_capture/desktop_media_list_controller.cc).

See [hardware acceptance](hardware-acceptance-2026-11-08.md) for the actual read-only monitor/audio/Bluetooth checks and remaining physical gates.

## Combined release verification

The final full Python regression run passed **810 tests, three skipped**
(`/tmp/abstract-recheck-shipping-tests.log`). The native Rust suite passed **30/30**.
The full run includes the forced worker-GC regression and the corrected Qt6 model
notification and deferred layout-polish checks; original behavioral assertions
remain in place.

Additional real private checks passed: all 16 taskbar variants; installed program
launcher/Settings smoke; Fcitx Unicode preedit/commit into native GTK; Qt5 AT-SPI
startup and later activation with button actions, focus, keyboard input and text
read; and Chrome WebRTC capture of eight changing frames followed by source
removal. The final native binary also imported a real Intel render-node DMA-BUF
and rejected an ordinary file descriptor without acquiring DRM master.

The compatibility library is 1,377,456 bytes, uses the exact distribution patch
series and a fingerprint gate, and adds no daemon. Current-session shell changes
can be reloaded without closing apps. Updated native IME globals and session-owned
portal startup activate at the next deliberate login; this recheck does not log
the user out.

Animation controls now bind reduced-motion/economy state directly rather than
introspecting a singleton signal while Settings pages are being constructed.
This removes a real Qt5 Connections warning and extra per-control QObject work;
the nine affected motion/layout checks pass on both Qt5 and Qt6.

## Applied result

Abstract package **0.1.1** is installed. Final post-polish full suite:
**810 tests, three skipped**, passed (`/tmp/abstract-verified-release-tests.log`).
The installed native smoke test passed all 14 actual Settings pages with zero
QML errors and clean private-fixture teardown. Installed session preflight and
charge-helper trust checks passed without acquiring the physical seat.

The live shell was reloaded once after verification. Both existing application
windows remained, the compositor and output configuration were unchanged, and
live QML errors were empty. Its process maps confirm the isolated Qt accessibility
module is loaded. No logout, lock, suspend, display mode change or hardware write
was performed. Native IME/portal session-owner updates remain staged for the next
normal Abstract login so current applications can stay open.
