TEMPLATE = subdirs

SUBDIRS = peeker
