# Abstract OS

Abstract is a native Qt Quick desktop for Linux, with a unified application/window launcher, local notes, and native system controls. The packaged baseline is Ubuntu 24.04 amd64 with systemd/logind; clean-install acceptance is tracked separately from development on Mint. The supported login path is Abstract’s native Wayland compositor. XFCE/X11 remains a development preview; Sway is retained only for isolated QA.

See [operational readiness](docs/operational-readiness.md) for current startup,
authentication, hardware write checks and the installed-session handoff.

## Install on a minimal base

The `abstract-shell` package supplies the desktop without choosing a login
manager. The optional `abstract-desktop` metapackage supplies the complete
LightDM-based desktop profile, standard system services and everyday tools.
Install both local release files with apt so dependencies are resolved:

```bash
sudo apt install ./abstract-shell_0.1.6_amd64.deb ./abstract-desktop_0.1.6_all.deb
```

On an existing desktop, install only `abstract-shell` to keep its login manager.
Use `abstract-session --check` for installation diagnostics and
`abstract-session --check-login` from the intended local login for seat, runtime
and bus diagnostics. Neither starts another compositor. Do not run the desktop
as root or change device permissions to bypass login setup.

See [clean-install acceptance and recovery](docs/clean-install-acceptance.md)
and [source-build baseline](docs/source-build-baseline.md) for the supported base,
VM evidence, first login, optional capabilities and remaining acceptance limits.
The lock currently requires a physical keyboard; screen-reader and touchscreen
lock entry are not implemented.

## Run

Choose **Abstract** at login for the installed native desktop. Keep Mint/Xfce
or a working text login available as recovery. Do not start a second physical session inside your current
one. Read [installation and verification](docs/independent-desktop.md).

```bash
abstract-session --check
```

For a disposable source preview inside an existing desktop:

```bash
./run-native-session.sh --nested
```

`./run-native.sh` is an X11 development preview only. Its supervisor temporarily
releases and restores XFCE panels and shortcuts; it is not the native login path.

- **Print Screen / camera icon:** built-in screenshot tool (display, area or a chosen window).
- **Ctrl Alt arrows:** previous workspace with Left/Up, next with Right/Down; wraps at the ends.
- **Alt Tab / Alt Shift Tab:** cycle windows; release Alt to activate, Escape to cancel.
- **Ctrl Alt Space:** open the unified app/window search.
- **Ctrl Alt Q:** exit the X11 development preview; use Session actions for normal native logout.
- **Controls icon in the spine:** Quick settings for controls, connections and power.
- **Super / Windows key:** one searchable view for applications, open windows, and system actions. Try “logout”, “microphone”, “Wi-Fi”, or “resolution”. Files & notes opens local files and notes.
- **Sound icon in the spine:** a separate Music and sound panel with playback and volume controls.

**Spine** is the new default layout: a single 64-pixel taskbar edge contains numbered workspaces, live application tasks, and grouped system controls. There is no separate top panel or bottom dock. The unified launcher and utility sheets attach beside that edge; their headers share the same alignment. Black, dark and light wallpapers use static geometric SVGs. Each monitor has its own workspace edge and wallpaper, while one active utility sheet moves to the selected monitor. Appearance → Style → Taskbar position offers Top, Bottom, Left, or Right. Classic is removed; existing preferences and saved local data are preserved. AI remains disabled.

Files & notes provides a file browser and an independent local note. Sharing, the shelf and Carry controls have been removed. Real app windows remain compositor-managed. Settings groups hardware and preferences, including Battery Health, Sound, Bluetooth, Brightness, Appearance, Notifications, Input, Lock, Displays, Shortcuts, Accessibility, Network and Power mode. Super+F10/F11/F12 provides mute/down/up without dedicated media keys; Super+Left/Right snaps windows and Super+Down restores size. These bindings are configurable.

Fold uses ordinary Qt Quick controls and short opacity/position transitions; reduced motion disables those transitions. It has no web engine, blur, live thumbnails, content indexing, filesystem polling, or automatic clipboard reads. Directory metadata scans start only when needed, inspect at most 256 entries and display at most 80 items on one lazy worker. Explicit text handoffs read at most 16 KiB; binary/large files carry references. Notes are capped at 64 KiB, saved with private atomic writes after a debounce and when Fold closes. The file model is independent of note edits, preventing list rebuilds while typing.

Apps and Unfold support arrow-key navigation and Enter/Space activation, with visible keyboard focus and accessible card/action labels. From app search, Down enters the app grid. The [November desktop audit](docs/desktop-audit-2026-11-07.md) records the latest fixes, test scope, and remaining daily-use features.

Before a planned shell-only reload, run `.venv/bin/python orbitctl.py prepare-reload` in the routed desktop environment and require `{"ok": true}`. This saves a pending Fold note synchronously; a failed save returns false so the caller can preserve the current shell. Unexpected crashes can still lose the current debounce interval.

`tools/qa-fold-wayland.py` verifies actual private Wayland input, file-to-note handoff, private note persistence, window focus/minimize/restore/close, app search, outside-click dismissal, themes, density and a 560×640 output. Its warm Economy/Black/compact/no-desktop-icons sample measured 158.2 MiB summed PSS with Fold open and 158.4 MiB closed, with idle CPU below the sampler’s 0.01% resolution over roughly ten seconds in both samples. These warm-heap samples are not an incremental open-versus-closed memory comparison. These figures include the private compositor, session bus, Orbit, Rust and active helpers after disposable apps closed; they are development measurements, not a 4 GB hardware certification. See `fold-metrics.json` for scope and RSS.

## Appearance

Fold styling covers the full shell: independent angular top-perimeter sections, centered clock, workspace underlines, vector status controls, named task tabs, flat utility sections, underlined tabs and matching panel headers. Its filter-free paper-fold wallpaper has Black, Dark and Light variants. Fold uses this background for Auto/Orbit, while explicit Solid/Dusk choices are preserved; the selected wallpaper remains independent of taskbar position. Fold is also available as an explicit background choice.

Appearance → Desktop → Placement → Top panel switches between **Separated** sections and one **Connected** strip. The choice persists; controls, clock, reserved height and input regions stay in place. Separated is the default.

`tools/qa-fold-shell-wayland.py --measure` verifies the perimeter and utilities using real private Wayland input, including 560-pixel layouts, both densities, theme changes, tooltip bounds and exact content-fit checks. Seventeen checks passed with no QML warnings or native-process restart. The latest complete-shell warm sample after visiting system panels measured 170.8 MiB PSS and 0.11% of one CPU core over 9.44 seconds. This includes the private compositor, bus, Orbit, Rust and session helpers without app windows; it is not target-hardware certification. See `fold-shell-metrics.json` for scope. The earlier `fold-metrics.json` records the workspace-only redesign sample.

Desktop folder icons are optional under Appearance → Desktop. They use a bounded directory watcher and cached file-type icons, without thumbnails or polling. Super provides Pin/Unpin controls and a Pinned filter; its right-click menu includes Add to Desktop for installed applications. Shortcut creation never overwrites existing files.

The signed-in username opens System usage from the top bar. CPU/RAM/swap sampling runs every two seconds only while that panel is open. Sound and playback use icon controls with tooltip/accessibility labels. The left dock launcher remains; the right Shelf shortcut is removed.

Window menus provide minimize, maximize, restore, snap and close through typed
native compositor actions. Minimized windows stay in the task bar. Applications
keep their own frames; older X11 apps receive controls in the compositor scene,
including dragging and corner resizing. There is no detached title-button strip
or screenshot workspace overlay. Window operations use a bounded serial worker;
focus changes and window metadata arrive through compositor events.

The local control server explicitly retains each live socket and its Python callback until QObject destruction, with a 64-client limit. This prevents cyclic GC on another worker from clearing a callback Qt can still invoke. Private forced-GC testing covered 100 focus/move/resize/title-height cycles, 17 actual minimize/restores, maximize/restore and closing only the intended view, without restarting Orbit or losing application views.

The native compositor moves frames and contents together and needs no periodic
shell-side frame tracking. Sway event/geometry code remains only for private QA.

**System → Appearance** uses three compact tabs with grouped setting rows, inline selectors and switches:

- **Style:** dark/light mode, compact spacing, six accent presets or a custom `#RRGGBB`, square/soft/rounded corners and matching application frames.
- **Desktop:** monitor selection, top/bottom/left/right taskbar placement, Auto/Solid/Orbit/Dusk backgrounds, a custom solid color, 12/24-hour clock and optional date.
- **Motion:** low-resource/Balanced profile, workspace transitions and Reduce motion. Reduced motion disables native workspace motion. No workspace screenshot transition exists.

Appearance → Style offers Light, Dark and Black. Black uses near-black shell surfaces, a filter-free static Orbit wallpaper and matching Wayland window frames with subdued accent outlines; application content follows its own theme support. The dock reserves a bounded native surface, fits its content inside it and limits input to the visible body, preventing clipped end buttons when apps open.

Reset appearance restores the visual defaults while preserving pinned apps and the performance profile. Settings persist atomically in `data/settings.json`; override with `ORBIT_SETTINGS_FILE`. Older files acquire the new defaults without losing existing choices. XFCE frame matching selects an installed Mint border theme closest to the accent and light/dark mode, restoring the original when Orbit exits. Wayland supports exact focus colors, title bars or outlines and border widths. Match app theme also updates live GTK/XSettings, GNOME GTK theme and the desktop light/dark preference, with independent restore journals. New app launches shed inherited GTK_THEME overrides. App-specific forced themes, terminal color profiles and some Qt/custom headers may still need their own System/Light option. “Orbit” is a working project name, not a user-confirmed product name.

Wayland panels use one fixed native buffer with a fitted inner body and input mask, avoiding Qt5 role recreation during tab/page changes. The existing transparent context surface also dismisses popovers when clicked outside, preserving immediate keyboard navigation. Verify repeated switching with `.venv/bin/python tools/qa-panels-wayland.py`, and real virtual-device clicks/tooltip/menu placement with `.venv/bin/python tools/qa-input-wayland.py`; both create isolated desktops.

Compact is the default: a 30-pixel top bar, tighter controls and smaller overlays. Background Auto uses a solid surface in Economy; explicit Orbit or Dusk backgrounds stay available without blur, live wallpaper or continuous animation. Wayland dock alignment retains its reserved workspace area through a tiny separate layer surface. The main shell can move to a selected monitor; hotplug falls back to the primary output and restores the saved preference on reconnect. Wayland surfaces are recreated on output changes so their actual output and reserved area move together.

## Low-resource mode

Default target: **2 CPU cores / 4 GB RAM**.

- Economy mode selects Qt's software renderer at startup, a solid background, opaque surfaces, and short eased panel transitions (110 ms opening, 85 ms closing).
- Balanced mode offers a vector wallpaper and 160 ms panel opening transitions. Switching profiles updates visuals immediately; renderer selection changes on the next launch. Advanced users can override `QT_QUICK_BACKEND` before starting.
- Window/workspace changes arrive over a blocking X11 event subscription. No periodic `wmctrl` spawning or window-list polling.
- The clock updates once a minute. Unix signals use `QSocketNotifier`, not a recurring heartbeat. AI jobs use events, not a polling timer.
- Only the open overlay is instantiated. Lists recycle delegates, icons decode at small sizes, and context pages contain 100 previews of at most 512 characters.
- Copy/open loads full content on demand. Search queries stored full text, including older pages. Large text items use Copy instead of dragging a truncated preview; file drags retain the complete URI.
- Context/file tasks share one worker; each system backend uses a bounded worker or blocking event loop. At most one provider request runs. No inference engine, embedding index, or model is loaded at login.
- The X11 native runtime uses Qt **Essentials** (~235 MiB on disk), without WebEngine/Addons. The Rust executable is ~2.1 MiB and uses Mint's existing SQLite library. Build tools/caches under `.toolchain/` and `backend/target/` are development artifacts, not required runtime memory.

Benchmark snapshots are in `baseline-metrics.json`, `economy-metrics.json`, `software-metrics.json`, and `final-metrics.json`. The baseline measures the previous native process. Final metrics report native-process RSS/CPU, Rust RSS, and supervisor RSS separately. RSS includes shared mappings; PSS is also reported for the native process. Measurements are idle samples on this display, not certification on a 2-core/4-GB machine; compositor, launched applications, GPU memory, and inference-server memory are excluded from native-process figures.

Reproduce with no other Orbit instance running:

```bash
.venv/bin/python tools/benchmark.py --profile economy --seconds 15 --output final-metrics.json
```

## AI (deferred)

AI is disabled for now: the navigation tab, top-bar entry, attachment actions and shortcut are hidden, and inference requests from the shell are blocked. The implementation is retained for a later phase.

Use an existing local or remote OpenAI-compatible chat-completions provider:

```bash
export ORBIT_AI_URL=http://127.0.0.1:11434/v1
export ORBIT_AI_MODEL=your-installed-model
# For a cloud provider, also export ORBIT_AI_KEY through your environment.
./run-native.sh
```

No model or provider is configured by default. A remote provider keeps inference memory off a 4-GB PC; a local model's memory is additional to Orbit's.

The Rust service streams SSE text, and also accepts non-streaming JSON responses. Only the prompt and selected attachments are sent. Maximum 20 attachments, a 200-KB attached-context budget, a 1-MB answer limit, and a 120-second request deadline. Cancel discards the answer and marks the worker for cancellation; a blocked network read may finish or time out before the provider connection is released. A second request is rejected until that worker ends. Cancellation cannot guarantee that a remote provider stops computation immediately.

Documents are untrusted data. The model has no filesystem or execution tools. Answers render as plain text. Only successful answers can be saved as context.

## Data and architecture

- `backend/src/main.rs`: Rust SQLite service, bounded context queries, full-object retrieval, typed create/share/remove/undo operations, and provider streaming. Private JSON-line RPC over stdin/stdout; no native network listener.
- `storage.py`: correlated RPC requests and event delivery. Native production uses Rust. An explicit Python adapter remains for isolated compatibility tests.
- `native_app.py`: Qt bridge, async file/content operations, clipboard, icon provider, X11 surface hints, and UI signals separated by responsibility.
- `x11_events.py`: one blocking X11 connection for desktop events and shortcuts, with short event-batch coalescing.
- `native/Theme.qml`: density, palette, and motion tokens. `native/Desktop.qml` owns independent desktop, bar, dock, overlay, and notice windows.
- `preferences.py`: validation and atomic preference writes.
- `supervise.py`: exclusive launch lock and XFCE panel restoration.

Context objects live in `data/orbit.sqlite3` (override with `ORBIT_DATA`). Sharing adds a link, preserving one object identity. Removing from a collection preserves other links. Undo covers the most recent share/unlink action; it is not a general filesystem undo system. Small explicit text-file captures store their text; binary captures store file references. No clipboard surveillance or background app-content scraping runs.

The optional earlier browser library (`python3 core.py`, http://127.0.0.1:4783) shares the database, but remains a separate Python development preview. It is not used by the native shell. `native/shell.qml` is the older Quickshell experiment; the tested native entry point is `Desktop.qml` through `native_app.py`.

## Build and validate

```bash
./tools/build-core.sh
.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python tools/qa-appearance.py
./run-native.sh --keep-panels --smoke-test --initial-panel settings --screenshot "$PWD/appearance-preview.png"
```

The build script uses the project-local Rust toolchain if present, two build workers, Cargo.lock, and Mint's existing SQLite runtime. To recreate Qt:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-native.txt
```

Qt/X11 also requires `libxcb-cursor0` and its standard dependencies. This project's `.runtime` contains the missing cursor library from Ubuntu Noble, with no system installation. Other distributions need their matching libraries.

Tests include native Qt-to-Rust capture/copy/undo, rollback, complete-text search/retrieval, pagination, explicit-context streaming, cancellation and concurrency limits, preference persistence, and avoiding context rebuilds on window updates. Rust unit tests cover stream parsing and storage transactions.

## Native Wayland session and system integration

Orbit now uses its own Rust/Smithay compositor with the Qt5/LayerShellQt shell.
The old **Abstract** Sway login entry and wrapper have been
unregistered. `install-wayland-session.sh` cannot reinstall it, and the old
launcher refuses a physical session. Mint/Xfce remains the recovery desktop.
Sway itself is kept for explicit private `--headless`/`--nested` QA; those fixtures
strip the physical native control environment and use their own D-Bus bus.

```bash
./run-native-session.sh --check
./run-native-session.sh --nested
```

The native entry is **Abstract**. See the
[login and recovery guide](docs/native-login.md). For a fresh checkout location:

```bash
sudo /home/aj/Projects/orbit-shell/tools/install-native-session.sh
```

Native login has been used on this PC, with confirmed 1920×1080 at 60 Hz and
100% scale saved in `data/outputs-native.json`. Authentication/resume, hotplug,
mixed-DPI and target 2-core/4-GB acceptance still need deliberate validation.
Ordinary launched applications inherit neither shell roles nor a forced Qt
platform. Standard XDG autostart and bounded shell recovery remain active.

The real swaylock PAM file is installed. Authentication, physical GPU/input, suspend/resume and real portal video streams still need validation after physical login; headless startup does not test those actions.

Manual, idle (10 minutes), and pre-suspend locking share `screen_lock.py`, with one locker per compositor and visible keyboard-layout/Caps Lock indicators. It prefers `.lock-runtime/bin/swaylock`, falling back to the distribution binary. `python3 tools/prepare-screen-lock.py` builds pinned upstream 1.8.6 with PAM against the host libraries; development packages stay inside the checkout. `python3 screen_lock.py --check` reports the selected version without locking. No authentication timeout automatically unlocks the screen. If unlocking becomes stuck, switch to a TTY with Ctrl+Alt+F3, log in normally there, then run `pkill -USR1 -u "$USER" -x swaylock` and return to the graphical VT (usually Ctrl+Alt+F7). This recovery is manual, after TTY authentication.

The built-in screenshot tool is available through **Print Screen**, the top-bar camera icon. It captures the selected display, a dragged area, or an explicitly chosen window into the XDG Pictures/Screenshots folder using private PNG files. The panel shows a clickable save destination that opens the output folder, without separate last-shot or folder buttons. Screenshots also copy to the clipboard by default; the panel toggle can disable copying. The tool hides before capture, uses no thumbnails or background capture loop, and limits capture size to 16 million physical pixels. Actual system-runtime headless tests cover full/area/window capture and selection cancellation using only disposable test windows.

Compatible media players expose title/artist and capability-checked play/pause/previous/next controls through MPRIS. Discovery and updates use D-Bus events, with no artwork downloads, position polling or automatic player startup.

Bluetooth has native power, device discovery, confirmed pairing, connect/disconnect and Forget controls. Discovery is user-started and stops after 30 seconds or when leaving the panel; pairing prompts also time out. Orbit never takes over the default BlueZ agent or accepts unsolicited requests. PIN-entry devices can use **More Bluetooth settings** in the installed system manager. Unit and private fake-BlueZ protocol tests cover actions without modifying real devices.

Brightness reads actual hardware values. Laptop backlights use logind SetBrightness, with installed brightnessctl as a fallback; requests coalesce and retain the last slider value. External displays support explicit DDC/CI detection/selection through installed ddcutil, verifying display identity before writing VCP 0x10. There is no background DDC scanning or gamma dimming. The GF340A HDMI monitor is now detected with normal-user I2C access. A live controller test changed 80%→79%→80% and verified readback; the original 80% was restored. The selected hardware identity is saved in data/brightness-target.json and reconnects with one startup detection/read, even if its display number changes; no brightness level is reapplied. Physical brightness/pairing still require compatible hardware and OS permissions.

Headphone battery levels appear beside connected devices and in Quick settings when BlueZ Battery1 reports a valid percentage. System battery percentage appears in the top bar and Battery panel. Battery health exposes 60/80/100% charge limits only when the selected system battery's driver exposes threshold controls and the user has write permission; actual driver-rounded limits are reread. No threshold is changed automatically. This desktop exposes no system battery, so the unavailable state is expected. Headphone charging limits are not standardized by BlueZ and are not simulated.

The launcher supports **Most used**, **Recent** and **A–Z**, with a clear-history action. App launches and actual focus changes update bounded local history at data/app-usage.json (desktop IDs, weighted counts and timestamps only). Disk writes run off the UI thread. There is no input/content monitoring or polling; focus score debounce still preserves immediate Recent ordering. Appearance reset preserves the selected launcher order.

Background apps now also include known catalog apps whose last window closed while their main process remains alive, including ChatGPT without a tray item. Linux pidfds remove exited apps without process polling, bounded to 64 watches. Exact tray PIDs prevent duplicates. Tracking starts when Orbit observes the app's window; it does not enumerate arbitrary services or infer unknown apps already hidden before launch. Click a tracked app to reopen its trusted desktop entry.

Audio uses PulseAudio/PipeWire's pactl interface; network controls use NetworkManager; battery uses UPower. Updates follow service events. Wayland includes a notification server with bounded history and Do Not Disturb, a polkit agent, idle locking and portal configuration. ScreenCast and FileChooser portal interfaces were verified; an actual screen-sharing stream was not exercised.

Notification cards and popups invoke the sender's default action. Named actions appear in the notification list; clients receive the standard `ActionInvoked` signal addressed to their original D-Bus connection. Without a default action, Orbit focuses a matching existing window or launches a matching installed desktop entry. Notification text never becomes a launch command. `tools/qa-notifications.py` checks the private D-Bus protocol; `tools/qa-notifications-wayland.py` verifies actual popup, card and action-button clicks in a disposable headless session.

The top-right **system tray** groups background apps under one crisp chevron beside the clock. Its compact popup shows app names and icons; left-click activates an app, right-click or the ellipsis opens its menu, and scrolling is forwarded when supported. Legacy icons also stay inside the popup. StatusNotifier/AppIndicator works on both backends, including icon pixmaps, status changes and D-Bus menus. X11 also hosts legacy XEmbed icons; legacy XEmbed-only apps are not yet bridged into the Wayland tray. Tray updates use D-Bus/X11 events, with no polling. Passive icons are hidden and exited apps are removed. Orbit does not change each app's close-to-tray preference: use its tray menu's Quit action to exit completely.

Validate the isolated tray protocol with `dbus-run-session -- .venv/bin/python tools/qa-tray.py`.

Lock, log out, switch user, sleep, restart and shut down live together in **Quick settings → Power**. Settings contains configuration rather than duplicated session actions. Super search remains a shortcut to the same guarded actions.

Super opens one searchable Apps + Windows + Actions view; Files & notes contains files and a local scratchpad. The taskbar supports all four screen edges; Classic is removed. Sharing is removed. The historical capture database remains accessible through the explicit development capture command and starts its Rust service only when used. Deferred Intelligence requires both the explicit ORBIT_DEV_AI=1 development environment and its saved preference; it is outside the normal desktop flow. These views have no live window previews or decorative rendering loops.

Right-click the desktop, dock apps, application entries, or window cards for contextual actions. The dock groups running windows, supports pinning and overflow, and includes applications beyond the previous four-window cutoff. Tooltips have their own unclipped surface. Panels fade and move slightly when opening, preserve content while closing, and fade between pages. Workspace changes move live client buffers in the native compositor; the old snapshot provider, image overlay and capture timer have been removed. Disable workspace motion in Appearance if preferred.

The latest isolated system-runtime headless Economy sample (1280×720, compact, Black, desktop icons enabled, panels closed) measured **136.1 MiB summed PSS**, **295.2 MiB summed RSS**, and **0.06% of one CPU core** over 16.05 seconds. It includes the private bus, Sway, Orbit, Rust and active helpers; no app windows, active screenshot job or explicit portal activation were present. RSS double-counts shared mappings. See `wayland-metrics.json` for the exact scope. This is an idle development sample, not physical target-hardware certification.

On X11, the supervisor temporarily releases XFCE's Alt-Tab and Print Screen shortcuts and restores them on exit, alongside its panel. `--keep-panels` leaves XFCE shortcuts intact and may prevent Orbit from owning those shortcuts. After forcibly killing the supervisor, run `python3 tools/restore-xfce.py` to recover saved bindings.

The native session retries a crashed shell up to three times with bounded backoff. Repeated shell failure preserves the compositor and application processes. An explicit clean shell exit ends the session. Launched apps and lock screens use independent process groups.

Remaining acceptance includes physical lock authentication, suspend/resume, mixed-DPI hardware, browser screen-sharing integration and target-hardware frame/input profiling. Actual portal video-frame delivery, stop and cancellation have passed private tests. Legacy Bluetooth PIN entry can use the installed system manager. Sharing is removed and AI is deferred. Orbit is a working shell with tested Sway and native nested paths; its native hardware session remains experimental.


## First physical login and fallback

Save work, run `xfce4-session-logout` and choose Log Out. In the login screen's session menu choose **Abstract**, then sign in. To return normally, use Abstract Quick settings → Log out… (available on every tab), then choose **Xfce Session** at login.

If Orbit returns immediately to the greeter, select **Xfce Session** and sign in again. If it remains black or unresponsive, switch to a text console with Ctrl Alt F3 and log in as your normal user. Stop only the native compositor and return to LightDM:

```bash
pkill -TERM -u "$USER" -x orbit-compositor
dm-tool switch-to-greeter
```

Then select **Xfce Session**. This recovery terminates apps in the Orbit session; save work before testing. After returning to Mint, inspect `data/native-session.log` for the native-login result. Development checks never automatically log out the physical session.

Quick settings is split into **Controls**, **Connections** and **Power**. External-display setup stays collapsed under Display options; Wi-Fi device-list refresh only runs when Connections is selected. AI is deferred and unavailable from shell entry points.

Open the top-panel sound icon, or **Controls → Audio devices & microphone…**, to choose speaker/headphone output and microphone input independently. Both have volume and mute controls. Device changes also reroute existing playback or microphone streams; screen/audio monitor recordings retain their source. Device lists update from audio-server events without periodic polling, and unavailable microphones remain disabled. Expanded device lists stay inside the sound panel and scroll only when needed.

## System controls

Open **Quick settings → System settings…** (or desktop right-click → System settings). The compact panel has a grouped, scrollable settings index; utility actions such as Screenshot, Background apps and Usage remain outside Settings.

- **Media keys:** volume up/down, output mute, microphone mute, play/pause, pause, stop, previous/next track, and display brightness use existing backends. Volume/brightness repeats are rate-limited; toggles do not autorepeat. No additional service is required.
- **Sound → Device profiles…:** explicitly choose a card's Off/Input/Output/Duplex/HDMI profiles from the audio server. Unconnected profiles are labeled and can be explicitly enabled for recovery. Hardware profile availability and persistence remain governed by the audio server.
- **Input:** keyboard layout, repeat rate/delay, pointer speed, natural scrolling and touchpad tap-to-click. Only explicit changes are applied/persisted; untouched layouts and device settings are preserved. Validated input rules also apply to matching devices connected later.
- **Lock:** idle locking, idle minutes, display-off minutes (0 disables), and locking before sleep. If locking is enabled, display power-off waits until at least five seconds after the lock timer. One swayidle child replaces the previous fixed timer; it exits with the shell even after a crash. These controls do not validate PAM passwords or change authentication policy.
- **Displays:** output, resolution/refresh, scale, rotation and X/Y arrangement. Apply starts a 15-second confirmation; Keep saves, Revert restores. A detached, temporary watchdog owns rollback even if the shell dies. Only confirmed native settings enter `outputs-native.json` in the user data directory; no permanent display watchdog runs.

`tools/qa-essentials-wayland.py` exercises actual private hardware-key routing, input persistence, lock preferences, and display Keep/Revert/timeout. It uses an unreachable audio server and isolated settings, never physical monitor/input changes. `--measure` records a warm private idle sample in `essentials-metrics.json`: about 210 MiB PSS and 0.12% of one CPU core over 8.59 seconds in this run. Scope includes Sway, private bus, shell, Rust and active helpers after larger-output tests; desktop icons and idle timers are off in the nested session. This is not target-hardware certification.


## Native compositor development

An experimental Rust/Smithay compositor is implemented with native, coordinated
workspace slides and no screenshot animation. It can run nested inside an existing
desktop or through the separately registered **Abstract** login
entry. [Build and validation](compositor/README.md) describes its current scope.
Read [native login and recovery](docs/native-login.md) before switching.
Native is now the supported Orbit login path. The old Sway login and screenshot
transition are retired; [hardware acceptance gates](docs/native-compositor-plan.md)
still apply.

## Recoverable arrangements and session essentials

The unified Super view has a **Saved layouts** button. Save the recognized open
application positions, preview the windows to reuse, choose explicitly when an
app has multiple windows, and apply. Missing apps are opened only by an explicit
Open action, followed by Refresh windows. Layouts store app identities and
geometry in a private `layouts.json` beside preferences, without document titles
or contents. Up to 12 layouts of 24 windows are supported.

Orbit-issued snap, move and maximize operations, plus applying a layout, keep a
bounded runtime **Undo arrangement** history. Undo skips closed/replaced clients
and fits survivors into current workareas. It restores bounds and floating state;
it does not reconstruct an arbitrary tiling tree or resurrect a closed app.

Application directories are watched for install/update/removal changes. Launcher
search uses localized names, generic names and keywords. GIO activation failures
are reported asynchronously; an accepted launch request is not a promise that an
application has opened a window.

Fresh real sessions process standard XDG autostart entries once per compositor
session. Shell reloads and nested QA do not replay startup applications. Logout
reviews open/minimized windows, requests graceful closes once, and waits for
save prompts/new windows. Blocking system protections and read failures stop the
flow; standing shutdown-delay requests are displayed without deadlocking logout.
There is no force-close path. Returning to work or dismissing the review cancels
its logout intent.

System settings includes default-app, startup and removable-device controls, plus
links to installed software, user, date/time and printer tools. Accessibility offers
Orca, input-method setup and an installed trusted Wayland keyboard. Installed
wvkbd typing is verified on the native backend. See the current verification
report for screen-reader and multilingual composition acceptance; physical
suspend/resume, mixed-DPI and KMS checks remain separate.

The Super launcher is centered on the selected monitor. Settings opens as a
regular centered window with a taskbar entry; it supports moving, resizing,
minimizing and maximizing. Reopen its task to return to the same settings page.

The public Orbit Desktop shortcut opens the existing native launcher when used inside Orbit. `run-native.sh` and `supervise.py` retain an X11 development preview and refuse inherited Wayland sessions; select the registered native session at login for the desktop. The normal smoke route covers current desktop panels; retained capture/provider compatibility has dedicated storage tests.

### Finding everyday actions

Super searches system actions as well as apps and windows. Exact actions such as
“log out”, “restart” and “shut down” appear ahead of generic help results; power
and exit actions open review rather than immediately ending the session. The
Power menu action in Super opens Quick settings → Power.
Quick settings keeps Lock, Log out and Switch user visible below its scrolling
controls. Its Power tab groups restart, shutdown and confirmed sleep.

Settings → Getting around explains search, shortcuts, session actions and
layouts. “Login” search opens Switch user when supported, otherwise the Power
menu. Switch user requires the
native session, LightDM and working screen lock; Orbit confirms the compositor
is locked before opening the greeter. These paths add no resident service or
background polling.

### Settings as an application window

Native Settings opens as a regular, centered window. Drag its titlebar, resize its
edges, use minimize/maximize/restore, and return through its taskbar icon or
Alt+Tab. Reopening Settings restores its existing window and selected page.
Its on-demand renderer shares the desktop's controllers over a user-private
local socket, without duplicate audio, display or idle services.

Appearance → Style has a theme dropdown for Midnight, Dune, Forest, Glacier,
Ember, Lavender, Porcelain and Graphite. Theme
selection updates the palette and matching vector wallpaper together; manual color changes
create a Custom style. Accessibility High contrast overrides theme colors until
turned off. Existing performance, motion, layout and accessibility choices remain
under user control.


### Matching wallpapers, borders and lock screen

Each preset has its own small bundled SVG wallpaper. Selecting a theme applies
its wallpaper; the Background picker still supports manual styles. Native
compositor builds with palette support add thin matching outlines without
replacing app titlebars or covering client pixels. Match window borders controls
this decoration, and fullscreen apps remain unoutlined. Installing that compositor
requires a new native login to replace a running session safely.

The existing swaylock/PAM backend now receives theme-matched colors and a cached
static wallpaper with a clear Password label, typing/Enter instructions, Esc and
Caps Lock guidance, and a no-click-needed explanation. Password characters remain
hidden; the real locker supplies typing, verification and failure feedback. The
image cache is bounded, no blur or animation is used, and image-rendering failure
falls back without disabling secure locking.

Appearance → Style includes Full edge / Fit contents taskbar length, Floating,
and live Square / Soft / Round shell corners. Pointer themes follow light/dark
mode using installed Bibata cursors. These use static rendering and existing
settings notifications, with no new polling or decorative background service.


Super search now includes density, pointer, microphone, brightness, battery
health, wallpaper, reduced motion, screenshots and Do Not Disturb. Setting
results select the owning tab and reveal/focus the exact control. Menu or
Shift+F10 opens launcher window/app menus. App order is explicitly scoped;
usage reset is behind App history and a deliberate Clear history confirmation.


Shell controls use short selection, press and page transitions. Economy shortens
them; Reduce motion stops active transitions and makes future changes immediate.
These effects add no idle animation, blur or capture process.

Native application opening, minimize/unminimize and maximize/restore effects
interpolate live buffers and matching decorations, without captures or copied
textures. Economy uses 140 ms; Balanced uses 200 ms. Reduce motion cancels them
immediately. Workspace-transition preference remains independent. A new native
binary activates at the next login; rebuilding never restarts the current
compositor or its applications.

The Abstract lock screen has a live local clock/date, signed-in user, and
system-battery status when present, with the selected theme’s wallpaper/colors.
Its single minute timer lives only in the locker; static wallpaper is cached.
The password field and authentication backend remain unchanged. A locker rebuild
applies on the next lock without a logout or restarting application windows.
