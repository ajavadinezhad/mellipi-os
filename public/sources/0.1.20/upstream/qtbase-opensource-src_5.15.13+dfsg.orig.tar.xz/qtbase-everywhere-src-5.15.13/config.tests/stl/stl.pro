SOURCES = stltest.cpp
